package model;

/**
 * Representation of what phase the game is currently being played in.
 */
public enum GamePhase {
  PLACING, BATTLE;
}
