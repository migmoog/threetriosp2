package cs3500.threetrios.provider.model;

/**
 * Possible colors for players to be.
 */
public enum PlayerColor {
  RED,
  BLUE
}
